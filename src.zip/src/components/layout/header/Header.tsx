import React from 'react'
import Logo from './Logo'
import Navbar from './Navbar'
import HeaderAction from './HeaderAction'
import Container from '../Container'

export default function Header() {
  return (
    <header className=' bg-white sticky
    top-0
    z-50
    transition-all
    duration-300
'>
      <Container>
        <div className='flex justify-between items-center h-20'>
          <Logo></Logo>
          <Navbar></Navbar>
          <HeaderAction></HeaderAction>
        </div>
      </Container>
    </header>
  )
}
