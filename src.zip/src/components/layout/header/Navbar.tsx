
import React from 'react'
import { IoChevronDown } from "react-icons/io5"
import Link from 'next/link'

const navItems = [
  { label: 'خانه', href:'/', hasDropdown: false },
  {
    label: 'دسته‌بندی ها',
    href:'/products',
    hasDropdown: true,
    categories: [
      { label: 'ست‌های خانگی',href: '/products?category=home-sets' },
      { label: 'کراپ/تاپ',href: '/products?category=crop-top' },
      { label: 'شلوار/دامن',href:'/products?category=pants-skirt' },
      { label: 'اکسسوری',href:'/products?category=accessory' }
    ],
  },
  { label: 'درباره ما', href: '/aboutUs', hasDropdown: false },
  { label: 'تماس با ما', href: '/contactUs', hasDropdown: false },
]

function Navbar() {
  return (
    <div className='flex gap-10 text-[16px] text-[var(--color-text)] font-medium tracking-wide'>
      {navItems.map((item) => (
        <div key={item.label} className='relative group py-2'>
          <Link href={item.href} className='flex items-center gap-1 cursor-pointer select-none'>
            <span>{item.label}</span>
            {item.hasDropdown && (
              <div className='transition-transform duration-300 group-hover:rotate-180'>
                <IoChevronDown
                  size={14}
                />
              </div>
            )}
          </Link>

          <span
            className='pointer-events-none absolute bottom-0 left-1/2 h-[2px] w-0 -translate-x-1/2
            bg-[var(--color-secondary-text)] transition-all duration-300 ease-out
            group-hover:w-full'
          />

          {/* category dropdown */}
          {item.hasDropdown && (
            <div
              className='absolute top-full right-0 z-50 w-56 pt-3
              opacity-0 invisible translate-y-2
              transition-all duration-300 ease-out
              group-hover:opacity-100 group-hover:visible group-hover:translate-y-0'
            >
              <div className='rounded-[var(--radius-md)] bg-white py-2 shadow-lg ring-1 ring-black/5'>
                {item.categories?.map((cat) => (
                  <div
                    key={cat.label}
                    className='cursor-pointer px-4 py-2 text-sm text-[var(--color-text)]
                    transition-colors hover:bg-gray-50 hover:text-[var(--color-primary,#5B6470)]'
                  >
                    {cat.label}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  )
}

export default Navbar
