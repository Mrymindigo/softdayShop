import React from 'react'

interface TitleProps{
  value:string
}

function Title({value}:TitleProps) {
  return (
    <div className="title pt-8 pb-8 flex flex-col justify-center items-center">
      <h3 className='text-xl text-[var(--color-text)] relative pb-9'>{value}</h3>
      <span className='h-[1px] w-[8%] bg-[var(--color-secondary-text)] absolute'></span>
    </div>
  )
}

export default Title