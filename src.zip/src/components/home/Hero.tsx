"use client";

import Image from "next/image"
import Link from "next/link"
import { use } from "react"

function Hero() {
  return (

    <div className='flex w-full h-screen'>

      <div className="relative w-2/3 h-full">
        <Image
          src={'/banner/hero-1.jpg'}
          alt="hero image"
          priority
          fill
          sizes="50vw"
          quality={100}
          className="object-cover" />
      </div>
      <div className="heroDescription w-1/2 h-full bg-[var(--secondary-beige)] flex justify-center">
        <div className="content  flex flex-col gap-8 w-[80%] justify-center items-start">
          <h2 className="text-5xl pb-6 text-[var(--color-text)]">آرامش از خانه شروع می‌شود</h2>
          <p className="text-lg pb-10 text-[var(--color-secondary-text)]">لباس‌های راحتی و خواب با طراحی مینیمال، برای صبح‌های آرام و شب‌های دلنشین</p>
          <Link href={'/products'} className="text-[16px] text-[var(--color-text)] bg-[var(--primary-blue)]/70 px-8 py-4 rounded-[var(--radius-xl)] hover:bg-[var(--primary-blue)] transition-[var(--transition-normal)]">مشاهده محصولات</Link>
        </div>
      </div>

    </div>
  )
}

export default Hero
