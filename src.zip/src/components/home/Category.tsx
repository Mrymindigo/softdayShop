
"use client";

import React from 'react'
import CategorySwiper from './CategorySwiper'
import Title from '../ui/Title';

function Category() {
  return (
    <div className="flex flex-col justify-center items-center bg-[var(--color-background)]" id='category'>
      <Title value='سافت کالکشن' />
      <CategorySwiper />
   </div>
  
  )
}

export default Category
